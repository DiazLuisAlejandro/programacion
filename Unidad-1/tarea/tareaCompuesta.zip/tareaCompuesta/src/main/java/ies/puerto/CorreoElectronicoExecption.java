package ies.puerto;

public class CorreoElectronicoExecption extends Exception{
    public CorreoElectronicoExecption(String mensaje){
        super (mensaje);
    }

}
